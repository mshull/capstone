
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Contacts capstoneAIContacts = new Contacts();
		App inApp = new App();
		inApp.showContacts();
	}
	public void showEvents(){
		
	}
	public void showContact(){
		
	}
	public String showContacts(){
		Contacts capstoneAIContacts = new Contacts();
		String[] capstoneAIContactsAll = capstoneAIContacts.all();
		for (int i=0; i<capstoneAIContactsAll.length; i++){
			 System.out.println(capstoneAIContactsAll[i]);
		}
		return "";
	}

	public void showNotes(){
		
	}
	public void showBlockchain(){
		
	}
	public int showEvent(int id){
		return 0;
	}
	public int showContact(int id){
		return 0;
	}
	public int showNote(int id){
		return 0;
	}
	

}
