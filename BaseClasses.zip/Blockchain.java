
public class Blockchain {

	
	public String[] stats(){ 
		return new String []{"a","b","c"};
	}
}
