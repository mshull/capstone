
public class Contact {



	public int id  ;

	public String infiniteAccount ;

	public String firstName ;

	public String lastName ;

	public String title ;

	public String company ;

	public String address ;

	public String addressSecond ;

	public String city ;

	public String state ;

	public String postalCode ;
	
	public String county ;
	
	public String country ;
	
	public String homePhone ;
	
	public String mobliePhone ;
	
	public String workPhone ;
	
	public String email ;


}
