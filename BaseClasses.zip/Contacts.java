
public class Contacts {


	public String[] all(){
		//Contacts CO = new Contacts();
		return new String []{"a","b","c"};
	}
	public int get(int id){
		//Contacts CO = new Contacts();
		return 0;
	}
}
