
public class Event {


	public int id ;

	public Object date ;

	public String name ;

	public String description ;


}
