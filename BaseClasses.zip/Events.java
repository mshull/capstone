
public class Events {



	public String[] all(){
		return null;
	}
	public int get (int id){
		return 0;
	}
	
}
