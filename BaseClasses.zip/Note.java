
public class Note {


	public int id;
	
	public Object date ;
	
	public String type ;
	
	public String parentld;
	
	public String title ;
	
	public String body ;
}
