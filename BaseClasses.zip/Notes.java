
public class Notes {


	public String[] all(){
		//Notes aINO = new Notes();
		return null;// aINO.
	}
	public int get(int id){
		//Notes aINO = new Notes();
		return 0;// aINO.
	}
	
	
}
